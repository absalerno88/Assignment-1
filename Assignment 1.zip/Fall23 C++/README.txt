
Follow the on-screen menu to interact with the array of integers:
Menu:
1. Check if integer exists in the array.
2. Modify value of an integer by index.
3. Add a new integer to the array.
4. Replace or remove an integer by index.
5. Display current data in array.
6. Exit.

Choose the desired operation by entering the corresponding number.

Features
Check if integer exists: Enter an integer, and the program will tell you if it exists in the array and at which index.

Modify value by index: Provide an index and a new value to modify an existing integer in the array.

Add a new integer: Enter a new integer value, and it will be added to the end of the array.

Replace or Remove: Provide an index and choose whether to replace the integer at that index with 0 or to remove it from the array.

Display data: View the current integers in the array.